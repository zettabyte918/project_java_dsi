package com.projet;

public class Main {

    public static void main(String[] args) {
        App.main(args);
    }
}
